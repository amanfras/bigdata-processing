package io.keepcoding.spark.exercise.speed

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, LongType, StringType, StructField, StructType, TimestampType}

object SpeedLayer {

  def TotalBytes(data: DataFrame, aggColumn: String): Future[Unit] = Future {

    data
      .select(col("timestamp"), col(aggColumn), col("bytes"))
      .withWatermark("timestamp", "6 minutes")
      .groupBy(window(col("timestamp"), "5 minutes"), col(aggColumn))
      .agg(sum(col("bytes")).as("total_bytes"))
      .select(
        col("window.start").cast(TimestampType).as("timestamp"),
        col(aggColumn).as("id"),
        col("total_bytes").as("value"),
        lit(aggColumn+"_total_bytes").as("type")
      )
      .writeStream
      .foreachBatch((dataset: DataFrame, batchId: Long) =>
        dataset
          .write
          .mode(SaveMode.Append)
          .format("jdbc")
          .option("driver", "org.postgresql.Driver")
          .option("url", "35.188.190.94")
          .option("dbtable", "bytes")
          .option("user", "postgres")
          .option("password", "keepcoding")
          .save()
      )
      .start()
      .awaitTermination()
  }

  def main(args: Array[String]): Unit = {
    val spark: SparkSession = SparkSession
      .builder()
      .master("local[20]")
      .appName("Streaming kafka")
      .getOrCreate()

    val devicesSchema = StructType(Seq(
      StructField("bytes", IntegerType),
      StructField("timestamp", TimestampType),
      StructField("app", StringType),
      StructField("id", StringType),
      StructField("antenna_id", StringType)
    ))

    val deviceStream = spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "34.125.116.149")
      .option("subscribe", "devices")
      .load()
      .select(from_json(col("value").cast(StringType), devicesSchema).as("json"))
      .select(col("json.*"))

    deviceStream
    .select(
      col("id"), col("antenna_id"), col("bytes"), col("app"),
      year(col("timestamp")).as("year"),
      month(col("timestamp")).as("month"),
      dayofmonth(col("timestamp")).as("day"),
      hour(col("timestamp")).as("hour")
    )
      .writeStream
      .partitionBy("year", "month", "day", "hour")
      .format("parquet")
      .option("path", "D:\\keepcoding\\big-data-processing\\mi-proyecto")
      .option("checkpointLocation", "D:\\keepcoding\\big-data-processing\\mi-proyecto")
      .start()
      .awaitTermination()

    val appStream = TotalBytes(deviceStream, "app")
    val userStream = TotalBytes(deviceStream.withColumnRenamed("id", "user"), "user")
    val antennaStream = TotalBytes(deviceStream.withColumnRenamed("antenna_id", "antenna"), "antenna")

  }
}
