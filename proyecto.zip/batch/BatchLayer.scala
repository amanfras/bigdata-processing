package io.keepcoding.spark.exercise.batch

import java.time.OffsetDateTime
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.TimestampType

object BatchLayer {
  def TotalBytes(devicesDataDF: DataFrame, colum: String, metric: String, filterDate: OffsetDateTime): DataFrame = {
    devicesDataDF
      .select(col(colum).as("id"), col("bytes"))
      .groupBy(col("id"))
      .agg(sum(col("bytes")).as("total"))
      .withColumn("type", lit(metric))
      .withColumn("timestamp", lit(filterDate.toEpochSecond).cast(TimestampType))
  }

  def writeJdbc(devicesDataDF: DataFrame, tableName: String):  Future[Unit] = Future {
    devicesDataDF
      .write
      .mode(SaveMode.Append)
      .format("jdbc")
      .option("driver", "org.postgresql.Driver")
      .option("url", "35.188.190.94")
      .option("dbtable", tableName)
      .option("user", "postgres")
      .option("password", "keepcoding")
      .save()
  }

  def main(filter : String): Unit = {
    val filterDate = OffsetDateTime.parse(filter)

    val spark = SparkSession.builder()
      .master("local[12]")
      .appName("BatchLayer")
      .getOrCreate()

    val userMetadata = spark
      .read
      .format("jdbc")
      .option("driver", "org.postgresql.Driver")
      .option("url", "35.188.190.94")
      .option("dbtable", "user_metadata")
      .option("user", "postgres")
      .option("password", "keepcoding")
      .load()

    val devicesData = spark
      .read
      .format("parquet")
      .option("path", "34.125.116.149")
      .option("path", "D:\\keepcoding\\big-data-processing\\mi-proyecto")
      .load()
      .filter(
          col("year") === filterDate.getYear &&
          col("month") === filterDate.getMonthValue &&
          col("day") === filterDate.getDayOfMonth &&
          col("hour") === filterDate.getHour
      )
      .persist()

    val userTotalBytes = TotalBytes(devicesData, "id", "user_bytes_total", filterDate).persist()
    val userLimit = userTotalBytes.as("user").select(col("id"), col("value"))
      .join(
        userMetadata.select(col("id"), col("email"), col("quota")).as("metadata"),
        col("user.id") === col("metadata.id") && col("user.value") > col("metadata.quota")
      )
      .select(col("metadata.email"), col("user.value").as("usage"), col("metadata.quota"), lit(filterDate.toEpochSecond).cast(TimestampType).as("timestamp"))

    Await.result(
      Future.sequence(Seq(
        writeJdbc(TotalBytes(devicesData, "antenna_id", "antenna_bytes_total", filterDate), "bytes_hourly"),
        writeJdbc(TotalBytes(devicesData, "app", "app_bytes_total", filterDate),  "bytes_hourly"),
        writeJdbc(userTotalBytes, "bytes_hourly"),
        writeJdbc(userLimit, "user_quota_limit")
      )), Duration.Inf
    )
  }
}
