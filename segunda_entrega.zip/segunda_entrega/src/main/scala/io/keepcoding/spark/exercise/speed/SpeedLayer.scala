package io.keepcoding.spark.exercise.speed

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.{Await, Future}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType, TimestampType}

import scala.concurrent.duration.Duration

object SpeedLayer {

  def TotalBytes(data: DataFrame, aggColumn: String, jdbcConnection: String): Future[Unit] = Future {

    data
      .select(col("timestamp").cast(TimestampType), col(aggColumn), col("bytes"))
      .withWatermark("timestamp", "6 minutes")
      .groupBy(window(col("timestamp"), "5 minutes"), col(aggColumn))
      .agg(sum(col("bytes")).as("total_bytes"))
      .select(
        col("window.start").cast(TimestampType).as("timestamp"),
        col(aggColumn).as("id"),
        col("total_bytes").as("value"),
        lit(aggColumn+"_total_bytes").as("type")
      )
      .writeStream
      .foreachBatch((dataset: DataFrame, batchId: Long) =>
        dataset
          .write
          .mode(SaveMode.Append)
          .format("jdbc")
          .option("driver", "org.postgresql.Driver")
          .option("url", jdbcConnection)
          .option("dbtable", "bytes")
          .option("user", "postgres")
          .option("password", "keepcoding")
          .save()
      )
      .start()
      .awaitTermination()
  }

  def saveToParquet(data: DataFrame, storageURI: String): Future[Unit] = Future {
    data
      .select(
        col("id"), col("antenna_id"), col("bytes"), col("app"),
        year(col("timestamp")).as("year"),
        month(col("timestamp")).as("month"),
        dayofmonth(col("timestamp")).as("day"),
        hour(col("timestamp")).as("hour")
      )
      .writeStream
      .partitionBy("year", "month", "day", "hour")
      .format("parquet")
      .option("path", storageURI + "/data")
      .option("checkpointLocation", storageURI + "/checkpoint")
      .start()
      .awaitTermination()
  }

  def main(args: Array[String]): Unit = {
    val kafkaIp = args(0)
    val jdbcConnection = args(1)
    val storageURI = args(2)


    val spark: SparkSession = SparkSession
      .builder()
      .master("local[20]")
      .appName("Streaming kafka")
      .getOrCreate()

    val devicesSchema = StructType(Seq(
      StructField("bytes", IntegerType),
      StructField("timestamp", TimestampType),
      StructField("app", StringType),
      StructField("id", StringType),
      StructField("antenna_id", StringType)
    ))

    val deviceStream = spark.readStream.format("kafka")
      .option("kafka.bootstrap.servers", kafkaIp)
      .option("subscribe", "devices")
      .load()
      .select(from_json(col("value").cast(StringType), devicesSchema).as("json"))
      .select(col("json.*"))


    val antennaFuture = TotalBytes(deviceStream.withColumnRenamed("antenna_id", "antenna"), "antenna",jdbcConnection)
    val userFuture = TotalBytes(deviceStream.withColumnRenamed("id", "user"), "user",jdbcConnection)
    val appFuture = TotalBytes(deviceStream, "app",jdbcConnection)
    val storageFuture = saveToParquet(deviceStream,storageURI)

    Await.result(Future.sequence(Seq(antennaFuture, userFuture, appFuture, storageFuture)), Duration.Inf)
  }
}
