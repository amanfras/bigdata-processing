package io.keepcoding.spark.exercise.batch

import java.time.OffsetDateTime
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}


object BatchLayer {
  def TotalBytes(devicesData: DataFrame, colum: String, metric: String, date: OffsetDateTime): DataFrame = {
    devicesData
      .select(col(colum).as("id"), col("bytes"))
      .groupBy(col("id"))
      .agg(sum(col("bytes")).as("value"))
      .withColumn("type", lit(metric))
      .withColumn("timestamp", lit(date.toEpochSecond).cast(TimestampType))
  }

  def writeJdbc(devicesDataDF: DataFrame, tableName: String, jdbcConnection: String) {
    devicesDataDF
      .write
      .mode(SaveMode.Append)
      .format("jdbc")
      .option("driver", "org.postgresql.Driver")
      .option("url", jdbcConnection)
      .option("dbtable", tableName)
      .option("user", "postgres")
      .option("password", "keepcoding")
      .save()
  }

  def main(args: Array[String]): Unit = {
    val storageURI = args(0)
    val jdbcConnection = args(1)
    val dateToFilter = OffsetDateTime.parse(args(2))

    val spark = SparkSession.builder()
      .master("local[20]")
      .appName("BatchLayer")
      .getOrCreate()

    val devicesData = spark
      .read
      .format("parquet")
      .option("path", storageURI + "/data")
      .load()
      .filter(
          col("year") === dateToFilter.getYear() &&
          col("month") === dateToFilter.getMonthValue() &&
          col("day") === dateToFilter.getDayOfMonth() &&
          col("hour") === dateToFilter.getHour()
      )
      .persist()

    val bytesAntenna = TotalBytes(devicesData, "antenna_id", "antenna_bytes_total", dateToFilter)
    writeJdbc(bytesAntenna,"bytes_hourly",jdbcConnection)

    val bytesUser = TotalBytes(devicesData, "id", "user_bytes_total", dateToFilter).persist()
    writeJdbc(bytesUser,"bytes_hourly",jdbcConnection)

    val bytesApp = TotalBytes(devicesData, "app", "app_bytes_total", dateToFilter)
    writeJdbc(bytesApp,"bytes_hourly",jdbcConnection)

    val userMetadata = spark
      .read
      .format("jdbc")
      .option("driver", "org.postgresql.Driver")
      .option("url", jdbcConnection)
      .option("dbtable", "user_metadata")
      .option("user", "postgres")
      .option("password", "keepcoding")
      .load()

    val userLimit = bytesUser.as("bytesUser")
      .select(col("id"), col("value"))
      .join(
        userMetadata.select(col("id"), col("email"), col("quota")).as("userMetadata"),
        col("bytesUser.id") === col("userMetadata.id") && col("bytesUser.value") > col("userMetadata.quota")
      )
      .select(col("userMetadata.email"), col("bytesUser.value").as("usage"), col("userMetadata.quota"), lit(dateToFilter.toEpochSecond).cast(TimestampType).as("timestamp"))

    writeJdbc(userLimit, "user_quota_limit",jdbcConnection)

  }
}
